#include "Sort.h"

+



void TestCountSort()
{
	//int a[] = { 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 };
	//int a[] = { 11, 9, 4, 3, 7, 1, 9, 8, 4, 3, 5, 0, 1, 3 };
	//int a[] = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11 };
	int a[] = { 10, 6, 7, 1, 3, 9, 4, 2, 5, 6, 5,7,3,3,3,4,2,5};

	CountSort(a, sizeof(a) / sizeof(int));
	PrintArray(a, sizeof(a) / sizeof(int));
}


void TestOP()
{
	srand(time(0));
	const int N = 10000000;
	int* a = (int*)malloc(sizeof(int)*N);


	for (int i = 0; i < N; ++i)
	{
		a[i] = rand();
	}

	int begin1 = clock();
	CountSort(a, sizeof(a)/sizeof(a[0]));
	int end1 = clock();



	printf("CountSort:%d\n", end1 - begin1);


	free(a);
	
}



int main()
{
	
	TestCountSort();

	//TestOP();


	return 0;
}