#include <stdio.h>
#include<time.h>
#include<stdlib.h>
#include<string.h>


void PrintArray(int* a, int n);

void CountSort(int* a, int n);
